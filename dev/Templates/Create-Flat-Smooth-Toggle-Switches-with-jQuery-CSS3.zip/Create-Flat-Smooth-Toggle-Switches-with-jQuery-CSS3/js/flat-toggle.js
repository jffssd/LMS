$('.flat-toggle').on('click', function() {
    $(this).toggleClass('on');
});
